export type CategoryId = 'sobremesas' | 'brigadeiros' | 'bombons' | 'garrafinhas';

export interface ProductItem {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  imageAlt: string;
}

export interface ProductCategory {
  id: CategoryId;
  label: string;
  title: string;
  subtitle: string;
  items: ProductItem[];
}

export const STORE_INFO = {
  name: 'Doces Gourmet',
  slogan: 'Uma história de amor, dedicação e sabor.',
  whatsappRaw: '5511954960817',
  phoneDisplay: '(11) 95496-0817',
  pixKey: '(11) 95496-0817',
  address: 'Estrada Geraldo Costa Camargo, 491',
  founders: 'Chef Ivan Fernandes & Amanda da Silva',
} as const;

export function formatBRL(value: number): string {
  return value.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });
}

export function buildWhatsAppUrl(message: string): string {
  return `https://wa.me/${STORE_INFO.whatsappRaw}?text=${encodeURIComponent(message)}`;
}

export const HERO_MEDIA = {
  image: '/assets/aistudio/WhatsApp_Image_2026-11-20_at_11.23.21__4__7a1288d4.jpeg',
  alt: 'Caixinhas de Brigadeiro de Chocolate da Doces Gourmet preparadas artesanalmente',
};

export const LOGO_MEDIA = {
  image: '/assets/aistudio/logo_doces_redonda.jpg',
  alt: 'Logo oficial A&I Doces Gourmet — Sabores que fazem a vida mais doce',
};

export const FOUNDERS_MEDIA = {
  image: '/assets/aistudio/WhatsApp_Image_2026-11-20_at_18.54.07_0b613eb7.jpeg',
  alt: 'Chef Ivan Fernandes e Amanda da Silva, fundadores e donos da Doces Gourmet',
};

export interface Testimonial {
  id: string;
  name: string;
  city: string;
  orderedItem: string;
  quote: string;
}

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 'depoimento-hortolandia',
    name: 'Mariana Costa',
    city: 'Hortolândia, SP',
    orderedItem: 'Brownie de Chocolate e Pudim de Doce de Leite',
    quote:
      'O Brownie de Chocolate chega super macio e com sabor intenso de cacau, e o Pudim de Doce de Leite derrete na boca. Virou nossa sobremesa favorita de domingo.',
  },
  {
    id: 'depoimento-sumare',
    name: 'Rafael Oliveira',
    city: 'Sumaré, SP',
    orderedItem: 'Bombom de Uva e Caixinha de Brigadeiros',
    quote:
      'Encomendei o Bombom de Uva e as caixinhas de brigadeiro de chocolate e Ninho para comemorar em família. Tudo fresquinho, bem embalado e atendimento muito atencioso.',
  },
  {
    id: 'depoimento-campinas',
    name: 'Camila Ferreira',
    city: 'Campinas, SP',
    orderedItem: 'Blondie de Pistache e Mousse de Maracujá na Garrafa',
    quote:
      'O Blondie de Pistache é surpreendente no equilíbrio do chocolate branco, e a Mousse de Maracujá na Garrafa é leve e prática. Dá para sentir o cuidado de chef em cada detalhe.',
  },
];

export const PRODUCT_CATEGORIES: ProductCategory[] = [
  {
    id: 'sobremesas',
    label: 'Sobremesas',
    title: 'Linha de Sobremesas',
    subtitle: 'Receitas clássicas preparadas com técnica de chef e ingredientes selecionados.',
    items: [
      {
        id: 'pudim-leite-condensado',
        name: 'Pudim de Leite Condensado',
        description: 'Cremoso, delicado e irresistível com calda dourada.',
        price: 8,
        image: '/assets/aistudio/WhatsApp_Image_2026-11-20_at_11.23.23__3__5e274c16.jpeg',
        imageAlt: 'Pudim de Leite Condensado cremoso da Doces Gourmet',
      },
      {
        id: 'pudim-doce-leite',
        name: 'Pudim de Doce de Leite',
        description: 'Textura aveludada e sabor marcante de doce de leite.',
        price: 8,
        image: '/assets/aistudio/WhatsApp_Image_2026-11-20_at_11.23.23__3__5e274c16.jpeg',
        imageAlt: 'Pudim de Doce de Leite cremoso da Doces Gourmet',
      },
      {
        id: 'brownie-chocolate',
        name: 'Brownie de Chocolate',
        description: 'Chocolate intenso, maciez e muito sabor.',
        price: 14,
        image: '/assets/aistudio/WhatsApp_Image_2026-11-20_at_11.23.23__5__8b6fabd2.jpeg',
        imageAlt: 'Brownie de Chocolate com cobertura cremosa e noz',
      },
      {
        id: 'blondie-pistache',
        name: 'Blondie de Pistache',
        description: 'Delicadeza, ganache cremosa e explosão de sabor.',
        price: 14,
        image: '/assets/aistudio/WhatsApp_Image_2026-11-20_at_11.23.23__4__e0cea711.jpeg',
        imageAlt: 'Blondie de Pistache com cobertura branca e pistache',
      },
    ],
  },
  {
    id: 'brigadeiros',
    label: 'Brigadeiros',
    title: 'Linha de Brigadeiros',
    subtitle: 'Brigadeiros enrolados na hora em caixinhas com 2 ou 4 unidades para presentear ou saborear.',
    items: [
      {
        id: 'brigadeiro-chocolate-4',
        name: 'Brigadeiro de Chocolate (Caixinha com 4)',
        description: 'Quatro brigadeiros cremosos de chocolate nobre.',
        price: 12,
        image: '/assets/aistudio/WhatsApp_Image_2026-11-20_at_11.23.21__4__7a1288d4.jpeg',
        imageAlt: 'Caixinha com 4 unidades de Brigadeiro de Chocolate',
      },
      {
        id: 'brigadeiro-chocolate-2',
        name: 'Brigadeiro de Chocolate (Caixinha com 2)',
        description: 'Duas unidades perfeitas para adoçar o seu dia.',
        price: 6,
        image: '/assets/aistudio/WhatsApp_Image_2026-11-20_at_11.23.21__4__7a1288d4.jpeg',
        imageAlt: 'Caixinha com 2 unidades de Brigadeiro de Chocolate',
      },
      {
        id: 'brigadeiro-ninho-4',
        name: 'Brigadeiro de Ninho (Caixinha com 4)',
        description: 'Quatro brigadeiros macios passados no leite Ninho.',
        price: 12,
        image: '/assets/aistudio/brigadeiro_ninho_crop.jpeg',
        imageAlt: 'Caixinha com 4 unidades de Brigadeiro de Ninho',
      },
      {
        id: 'brigadeiro-ninho-2',
        name: 'Brigadeiro de Ninho (Caixinha com 2)',
        description: 'Duas unidades cremosas de brigadeiro de Ninho.',
        price: 6,
        image: '/assets/aistudio/brigadeiro_ninho_crop.jpeg',
        imageAlt: 'Caixinha com 2 unidades de Brigadeiro de Ninho',
      },
    ],
  },
  {
    id: 'bombons',
    label: 'Bombons',
    title: 'Linha de Bombons',
    subtitle: 'Camadas generosas de creme artesanal e cobertura de chocolate no pote.',
    items: [
      {
        id: 'bombom-uva',
        name: 'Bombom de Uva',
        description: 'Uvas frescas envolvidas em brigadeiro branco e chocolate.',
        price: 12,
        image: '/assets/aistudio/WhatsApp_Image_2026-11-20_at_11.23.23__1__03926fb3.jpeg',
        imageAlt: 'Bombom de Uva no pote com ganache de chocolate',
      },
      {
        id: 'bombom-oreo',
        name: 'Bombom de Oreo',
        description: 'Creme suave com pedaços de Oreo e ganache escura.',
        price: 12,
        image: '/assets/aistudio/WhatsApp_Image_2026-11-20_at_11.23.22_0b5ec941.jpeg',
        imageAlt: 'Bombom de Oreo no pote com biscoito Oreo por cima',
      },
      {
        id: 'bombom-pacoca',
        name: 'Bombom de Paçoca',
        description: 'Creme artesanal de amendoim coberto com paçoca e chocolate.',
        price: 12,
        image: '/assets/aistudio/WhatsApp_Image_2026-11-20_at_11.23.23__2__404a5598.jpeg',
        imageAlt: 'Bombom de Paçoca no pote finalizado com paçoca',
      },
      {
        id: 'bombom-palha-italiana',
        name: 'Bombom de Palha Italiana Cremosa',
        description: 'Brigadeiro cremoso, biscoito crocante e ganache brilhante.',
        price: 12,
        image: '/assets/aistudio/WhatsApp_Image_2026-11-20_at_11.23.23_150bc259.jpeg',
        imageAlt: 'Bombom de Palha Italiana Cremosa no pote',
      },
    ],
  },
  {
    id: 'garrafinhas',
    label: 'Garrafinhas',
    title: 'Linha de Delícias na Garrafinha',
    subtitle: 'Mousses cremosas e açaí encorpado em garrafinhas práticas para saborear gelado.',
    items: [
      {
        id: 'mousse-maracuja',
        name: 'Mousse de Maracujá na Garrafa',
        description: 'Mousse aerado com calda natural e sementes da fruta.',
        price: 16,
        image: '/assets/aistudio/WhatsApp_Image_2026-11-20_at_11.23.21__3__dcc06c62.jpeg',
        imageAlt: 'Mousse de Maracujá na Garrafa com calda de maracujá',
      },
      {
        id: 'mousse-morango',
        name: 'Mousse de Morango na Garrafa',
        description: 'Creme aveludado com pedaços frescos de morango.',
        price: 16,
        image: '/assets/aistudio/WhatsApp_Image_2026-11-20_at_11.23.21__1__966e09bc.jpeg',
        imageAlt: 'Mousse de Morango na Garrafa com pedaços de fruta',
      },
      {
        id: 'acai-garrafa',
        name: 'Açaí na Garrafa',
        description: 'Açaí cremoso finalizado com camada de leite condensado.',
        price: 16,
        image: '/assets/aistudio/WhatsApp_Image_2026-11-20_at_11.23.21_5dc6ac59.jpeg',
        imageAlt: 'Açaí na Garrafa cremoso da Doces Gourmet',
      },
    ],
  },
];

export const STORY_PARAGRAPHS = [
  'Por trás de cada doce, existe uma história. Meu nome é Ivan Fernandes, sou chef de cozinha desde 2005 e iniciei minha trajetória na gastronomia em 2001. Ao longo de mais de 25 anos em cozinhas nacionais, internacionais e regionais, encontrei na confeitaria a minha maior paixão.',
  'Ao meu lado está Amanda da Silva, minha esposa e companheira há mais de dez anos. Amanda também dedicou seis anos à confeitaria até seguir uma nova missão como enfermeira — profissão que exerce com amor e dedicação — sem nunca deixar os doces para trás, estando hoje à frente da nossa loja.',
  'Foi da união de nossas histórias, experiências e sonhos que nasceu a Doces Gourmet. Mais do que preparar sobremesas, queremos proporcionar momentos especiais, despertar emoções e criar memórias através de cada sabor.',
];

export const STORY_QUOTE =
  'Porque acreditamos que cozinhar é uma forma de amar, servir é uma forma de cuidar e adoçar a vida é a nossa maior alegria.';

export const DOCERIA_VALUES = [
  {
    index: '01.',
    title: 'Qualidade em cada doce',
    description: 'Mais de 25 anos de experiência gastronômica aplicados em receitas artesanais de alto padrão.',
  },
  {
    index: '02.',
    title: 'Feito com muito amor',
    description: 'Cada pudim, brownie, blondie, brigadeiro, bombom e garrafinha é preparado com cuidado familiar.',
  },
  {
    index: '03.',
    title: 'Sabor que encanta',
    description: 'Peça direto pelo WhatsApp com pagamento facilitado via PIX e atendimento próximo.',
  },
];
