import { useState } from 'react';
import { CakeSlice } from 'lucide-react';

interface MediaFrameProps {
  src: string;
  alt: string;
  className?: string;
  imgClassName?: string;
  priority?: boolean;
  label?: string;
}

export function MediaFrame({
  src,
  alt,
  className = '',
  imgClassName = '',
  priority = false,
  label,
}: MediaFrameProps) {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`relative flex flex-col items-center justify-center gap-3 overflow-hidden bg-chocolate text-cream p-8 text-center ${className}`}
      >
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gold text-ink-dark">
          <CakeSlice className="h-6 w-6" aria-hidden="true" />
        </div>
        <p className="font-display text-base font-medium text-cream max-w-xs">
          {label || alt}
        </p>
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden bg-chocolate ${className}`}>
      <img
        src={src}
        alt={alt}
        referrerPolicy="no-referrer"
        loading={priority ? 'eager' : 'lazy'}
        decoding="async"
        fetchPriority={priority ? 'high' : 'auto'}
        onError={() => setHasError(true)}
        className={`h-full w-full object-cover photo-grade ${imgClassName}`}
      />
    </div>
  );
}
