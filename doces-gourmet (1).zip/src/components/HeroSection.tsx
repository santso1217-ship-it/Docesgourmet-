import { ArrowDownRight, MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { HERO_MEDIA, LOGO_MEDIA, STORE_INFO, buildWhatsAppUrl } from '../data/catalog';
import { MediaFrame } from './MediaFrame';

export function HeroSection() {
  const whatsappHref = buildWhatsAppUrl(
    'Olá! Vi o site da Doces Gourmet e gostaria de fazer um pedido.'
  );

  return (
    <section
      id="inicio"
      className="hero-glow relative overflow-hidden bg-cocoa pt-10 pb-16 sm:pt-14 sm:pb-20 lg:pt-16 lg:pb-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 items-stretch gap-10 lg:grid-cols-12 lg:gap-12">
          <div className="flex flex-col justify-center lg:col-span-6">
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
              className="mb-4 text-sm font-bold tracking-wide text-gold"
            >
              Doces Gourmet · {STORE_INFO.founders}
            </motion.p>

            <motion.h1
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.05, ease: [0.16, 1, 0.3, 1] }}
              className="font-display text-[clamp(2.45rem,4.9vw,4.25rem)] font-semibold leading-[1.04] tracking-tight text-cream"
            >
              {STORE_INFO.slogan}
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
              className="mt-6 max-w-md text-lg leading-relaxed text-cream-muted"
            >
              Pudins, brownies, blondie de pistache, brigadeiros, bombons no pote e delícias na garrafinha.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
              className="mt-9 flex flex-wrap items-center gap-6"
            >
              <a
                href={whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[48px] items-center justify-center gap-2.5 rounded-full bg-gold px-7 py-3.5 text-base font-bold text-ink-dark whitespace-nowrap shrink-0 transition-all duration-200 hover:bg-gold-hover hover:-translate-y-0.5 active:translate-y-0"
              >
                <MessageCircle className="h-5 w-5 shrink-0" aria-hidden="true" />
                <span>Conversar no WhatsApp</span>
              </a>

              <a
                href="#produtos"
                className="inline-flex min-h-[44px] items-center gap-1.5 text-base font-semibold text-cream whitespace-nowrap shrink-0 transition-colors duration-200 hover:text-gold"
              >
                <span>Ver cardápio</span>
                <ArrowDownRight className="h-4 w-4 text-gold" aria-hidden="true" />
              </a>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="relative lg:col-span-6"
          >
            <div
              aria-hidden="true"
              className="absolute -bottom-4 -right-4 top-6 left-6 rounded-[2rem] bg-gold/25 sm:rounded-[2.75rem]"
            />
            <MediaFrame
              src={HERO_MEDIA.image}
              alt={HERO_MEDIA.alt}
              label="Doces Gourmet"
              priority
              className="relative aspect-[4/3] w-full rounded-[2rem] border-2 border-gold/50 sm:rounded-[2.75rem] lg:h-full lg:min-h-[440px]"
            />
            <div className="absolute -bottom-5 left-4 h-24 w-24 overflow-hidden rounded-full border-2 border-gold bg-cocoa shadow-lg sm:-left-5 sm:h-28 sm:w-28">
              <img
                src={LOGO_MEDIA.image}
                alt={LOGO_MEDIA.alt}
                referrerPolicy="no-referrer"
                className="h-full w-full scale-[1.03] object-cover"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
