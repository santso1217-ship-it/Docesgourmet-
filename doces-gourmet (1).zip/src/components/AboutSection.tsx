import { motion } from 'motion/react';
import {
  FOUNDERS_MEDIA,
  STORE_INFO,
  STORY_PARAGRAPHS,
  STORY_QUOTE,
} from '../data/catalog';
import { MediaFrame } from './MediaFrame';

export function AboutSection() {
  return (
    <section id="sobre" className="bg-chocolate py-20 text-cream sm:py-28 lg:py-32">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-12 lg:gap-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.18 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5"
          >
            <div className="relative mx-auto max-w-md lg:max-w-none">
              <div
                aria-hidden="true"
                className="absolute -inset-3 rounded-[2.25rem] bg-gold/25"
              />
              <MediaFrame
                src={FOUNDERS_MEDIA.image}
                alt={FOUNDERS_MEDIA.alt}
                label={STORE_INFO.founders}
                className="relative aspect-square w-full rounded-[2rem] border-2 border-gold/60"
                imgClassName="object-top"
              />
            </div>
            <p className="mt-4 text-center text-sm font-semibold text-gold">
              {STORE_INFO.founders} · Fundadores da {STORE_INFO.name}
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.18 }}
            transition={{ duration: 0.6, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7"
          >
            <p className="text-sm font-bold tracking-wide text-gold">Nossa História</p>
            <h2 className="mt-2 font-display text-[clamp(2rem,3.8vw,3.15rem)] font-semibold leading-[1.08] tracking-tight text-cream">
              Duas histórias, um sonho transformado em sabor.
            </h2>

            <div className="mt-6 space-y-4 text-base leading-relaxed text-cream-muted sm:text-[1.0625rem]">
              {STORY_PARAGRAPHS.map((paragraph, idx) => (
                <p key={idx}>{paragraph}</p>
              ))}
            </div>

            <div className="mt-8 rounded-2xl border border-gold/45 bg-cocoa p-6">
              <p className="font-display text-lg font-medium leading-relaxed text-cream">
                “{STORY_QUOTE}”
              </p>
              <div className="mt-4 border-t border-border-dark pt-4 text-sm">
                <p className="font-bold text-gold">{STORE_INFO.founders}</p>
                <p className="text-cream-muted">Fundadores da {STORE_INFO.name}</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
