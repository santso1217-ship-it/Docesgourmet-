import { LOGO_MEDIA, STORE_INFO, buildWhatsAppUrl } from '../data/catalog';

export function Footer() {
  const whatsappHref = buildWhatsAppUrl(
    'Olá! Gostaria de falar com a Doces Gourmet.'
  );

  return (
    <footer className="border-t border-border-dark bg-cocoa py-12 text-cream sm:py-16">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-8 md:flex-row md:items-start">
          <div className="flex items-start gap-4 max-w-md">
            <div className="h-14 w-14 overflow-hidden rounded-full border border-gold/60 bg-cocoa shrink-0">
              <img
                src={LOGO_MEDIA.image}
                alt={LOGO_MEDIA.alt}
                referrerPolicy="no-referrer"
                loading="lazy"
                className="h-full w-full scale-[1.03] object-cover"
              />
            </div>
            <div>
              <a
                href="#inicio"
                className="font-display text-2xl font-semibold tracking-tight text-gold"
              >
                {STORE_INFO.name}
              </a>
              <p className="mt-1 text-sm font-semibold text-cream">
                {STORE_INFO.founders}
              </p>
              <p className="mt-1.5 text-sm leading-relaxed text-cream-muted">
                {STORE_INFO.address}
              </p>
              <p className="mt-1 text-sm font-semibold text-gold tabular-nums">
                <a
                  href={whatsappHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="transition-colors hover:text-cream"
                >
                  WhatsApp / Pix: {STORE_INFO.phoneDisplay}
                </a>
              </p>
              <p className="mt-1 text-xs font-medium text-cream-muted">
                Aceitamos Pix, cartão de débito e crédito
              </p>
            </div>
          </div>

          <nav
            aria-label="Navegação do rodapé"
            className="flex flex-wrap items-center gap-x-8 gap-y-3 text-sm font-semibold text-cream-muted"
          >
            <a href="#inicio" className="transition-colors hover:text-gold">
              Início
            </a>
            <a href="#produtos" className="transition-colors hover:text-gold">
              Cardápio
            </a>
            <a href="#sobre" className="transition-colors hover:text-gold">
              Nossa História
            </a>
            <a href="#contato" className="transition-colors hover:text-gold">
              Contato
            </a>
          </nav>
        </div>

        <div className="mt-10 border-t border-border-dark pt-6 text-xs text-cream-muted">
          <p>© {new Date().getFullYear()} {STORE_INFO.name}. Confeitaria Artesanal.</p>
        </div>
      </div>
    </footer>
  );
}
