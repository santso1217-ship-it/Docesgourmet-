import { useState } from 'react';
import { Menu, MessageCircle, X } from 'lucide-react';
import { LOGO_MEDIA, STORE_INFO, buildWhatsAppUrl } from '../data/catalog';

const NAV_LINKS = [
  { href: '#inicio', label: 'Início' },
  { href: '#produtos', label: 'Cardápio' },
  { href: '#sobre', label: 'Nossa História' },
  { href: '#contato', label: 'Contato' },
];

export function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const whatsappHref = buildWhatsAppUrl(
    'Olá! Gostaria de fazer um pedido na Doces Gourmet.'
  );

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border-dark bg-cocoa/95 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
        <a
          href="#inicio"
          className="inline-flex items-center gap-3 font-display text-xl sm:text-2xl font-semibold tracking-tight text-gold whitespace-nowrap shrink-0 transition-colors hover:text-cream"
        >
          <span className="h-10 w-10 overflow-hidden rounded-full border border-gold/60 bg-cocoa shrink-0">
            <img
              src={LOGO_MEDIA.image}
              alt={LOGO_MEDIA.alt}
              referrerPolicy="no-referrer"
              className="h-full w-full scale-[1.03] object-cover"
            />
          </span>
          <span>{STORE_INFO.name}</span>
        </a>

        <nav
          aria-label="Navegação principal"
          className="hidden md:flex items-center gap-8 text-sm font-semibold text-cream-muted"
        >
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="relative py-1 whitespace-nowrap shrink-0 transition-colors duration-200 hover:text-gold after:absolute after:bottom-0 after:left-0 after:h-[1.5px] after:w-0 after:bg-gold after:transition-all after:duration-200 hover:after:w-full"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3 shrink-0">
          <a
            href={whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center justify-center gap-2 rounded-full bg-gold px-5 py-2.5 text-sm font-bold text-ink-dark whitespace-nowrap shrink-0 transition-all duration-200 hover:bg-gold-hover hover:-translate-y-0.5 active:translate-y-0"
          >
            <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
            <span>Conversar no WhatsApp</span>
          </a>

          <a
            href={whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Conversar no WhatsApp"
            className="inline-flex sm:hidden h-11 w-11 items-center justify-center rounded-full bg-gold text-ink-dark shrink-0 transition-colors hover:bg-gold-hover"
          >
            <MessageCircle className="h-5 w-5" aria-hidden="true" />
          </a>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-expanded={mobileOpen}
            aria-label={mobileOpen ? 'Fechar menu' : 'Abrir menu'}
            className="inline-flex md:hidden h-11 w-11 items-center justify-center rounded-full border border-border-dark bg-chocolate text-cream transition-colors hover:border-gold hover:text-gold"
          >
            {mobileOpen ? (
              <X className="h-5 w-5" aria-hidden="true" />
            ) : (
              <Menu className="h-5 w-5" aria-hidden="true" />
            )}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden border-t border-border-dark bg-cocoa px-4 py-4">
          <nav aria-label="Navegação mobile" className="flex flex-col gap-1">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="flex min-h-[44px] items-center rounded-xl px-3 text-base font-semibold text-cream transition-colors hover:bg-chocolate hover:text-gold"
              >
                {link.label}
              </a>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
