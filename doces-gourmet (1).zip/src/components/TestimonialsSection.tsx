import { Quote } from 'lucide-react';
import { motion } from 'motion/react';
import { TESTIMONIALS } from '../data/catalog';

export function TestimonialsSection() {
  return (
    <section
      aria-labelledby="depoimentos-heading"
      className="bg-cocoa py-20 text-cream sm:py-28 lg:py-32"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between"
        >
          <div className="max-w-xl">
            <p className="text-sm font-bold tracking-wide text-gold">
              Depoimentos de clientes
            </p>
            <h2
              id="depoimentos-heading"
              className="mt-2 font-display text-[clamp(2rem,3.6vw,3.1rem)] font-semibold leading-[1.08] tracking-tight text-cream"
            >
              Quem provou, recomenda.
            </h2>
          </div>
          <p className="max-w-sm text-sm leading-relaxed text-cream-muted md:text-right">
            Histórias reais de quem já adoçou momentos especiais em Hortolândia, Sumaré e Campinas.
          </p>
        </motion.div>

        <div className="mt-14 grid grid-cols-1 gap-7 md:grid-cols-3">
          {TESTIMONIALS.map((item, idx) => (
            <motion.blockquote
              key={item.id}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.18 }}
              transition={{ duration: 0.55, delay: idx * 0.07, ease: [0.16, 1, 0.3, 1] }}
              className="flex flex-col justify-between rounded-[1.75rem] border border-gold/30 bg-chocolate p-7 sm:p-8"
            >
              <div>
                <Quote
                  className="h-6 w-6 text-gold"
                  aria-hidden="true"
                />
                <p className="mt-5 text-base leading-relaxed text-cream">
                  “{item.quote}”
                </p>
              </div>

              <footer className="mt-8 border-t border-border-dark pt-4">
                <p className="font-display text-lg font-semibold text-gold">
                  {item.name}
                </p>
                <p className="mt-0.5 text-sm text-cream-muted">
                  <span>{item.city}</span>
                  <span aria-hidden="true" className="mx-2">
                    ·
                  </span>
                  <span>{item.orderedItem}</span>
                </p>
              </footer>
            </motion.blockquote>
          ))}
        </div>
      </div>
    </section>
  );
}
