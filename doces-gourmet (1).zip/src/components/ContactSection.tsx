import { FormEvent, useRef, useState } from 'react';
import { AlertCircle, CheckCircle2, CreditCard, MapPin, MessageCircle, Phone } from 'lucide-react';
import { motion } from 'motion/react';
import { STORE_INFO, buildWhatsAppUrl } from '../data/catalog';

interface FormErrors {
  name?: string;
  message?: string;
}

const INTEREST_OPTIONS = [
  'Linha de Sobremesas (Pudim, Brownie, Blondie)',
  'Linha de Brigadeiros (Caixinha 2 ou 4 un.)',
  'Linha de Bombons no Pote',
  'Linha de Delícias na Garrafinha',
  'Pedido misto / Encomenda especial',
];

export function ContactSection() {
  const [name, setName] = useState('');
  const [interest, setInterest] = useState(INTEREST_OPTIONS[0]);
  const [message, setMessage] = useState('');
  const [errors, setErrors] = useState<FormErrors>({});
  const [submittedUrl, setSubmittedUrl] = useState<string | null>(null);
  const hiddenLinkRef = useRef<HTMLAnchorElement | null>(null);

  const directWhatsappUrl = buildWhatsAppUrl(
    'Olá! Gostaria de fazer um pedido na Doces Gourmet.'
  );

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const trimmedName = name.trim();
    const trimmedMessage = message.trim();
    const nextErrors: FormErrors = {};

    if (trimmedName.length < 2) {
      nextErrors.name = 'Informe seu nome para personalizar o atendimento.';
    }
    if (trimmedMessage.length < 5) {
      nextErrors.message = 'Conte quais doces ou sabores você gostaria de pedir.';
    }

    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      setSubmittedUrl(null);
      return;
    }

    setErrors({});
    const composedText = `Olá! Me chamo ${trimmedName}. Tenho interesse em: ${interest}. ${trimmedMessage}`;
    const url = buildWhatsAppUrl(composedText);
    setSubmittedUrl(url);

    requestAnimationFrame(() => {
      hiddenLinkRef.current?.click();
    });
  }

  return (
    <section id="contato" className="bg-honey py-20 text-ink-dark sm:py-28 lg:py-32">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-16">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-between lg:col-span-5"
          >
            <div>
              <p className="text-sm font-bold tracking-wide text-chocolate">
                Contato e localização
              </p>
              <h2 className="mt-2 font-display text-[clamp(2rem,3.6vw,3.1rem)] font-semibold leading-[1.08] tracking-tight text-ink-dark">
                Peça direto pelo WhatsApp.
              </h2>
              <p className="mt-4 max-w-md text-base leading-relaxed text-ink-muted">
                Atendimento com carinho de quem ama o que faz. Aceitamos Pix, cartão de débito e crédito.
              </p>

              <div className="mt-10 space-y-6 border-t border-border-warm pt-8">
                <div className="flex items-start gap-3.5">
                  <MapPin
                    className="mt-1 h-5 w-5 shrink-0 text-chocolate"
                    aria-hidden="true"
                  />
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wider text-ink-muted">
                      Endereço
                    </p>
                    <p className="mt-1 text-base font-bold leading-snug text-ink-dark">
                      {STORE_INFO.address}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <Phone
                    className="mt-1 h-5 w-5 shrink-0 text-chocolate"
                    aria-hidden="true"
                  />
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wider text-ink-muted">
                      WhatsApp e Pix
                    </p>
                    <a
                      href={directWhatsappUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-1 inline-block text-base font-bold text-ink-dark tabular-nums transition-colors hover:text-chocolate"
                    >
                      {STORE_INFO.phoneDisplay}
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <CreditCard
                    className="mt-1 h-5 w-5 shrink-0 text-chocolate"
                    aria-hidden="true"
                  />
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wider text-ink-muted">
                      Formas de pagamento
                    </p>
                    <p className="mt-1 text-base font-bold leading-snug text-ink-dark">
                      Aceitamos Pix, cartão de débito e crédito
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-10">
              <a
                href={directWhatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[48px] items-center justify-center gap-2.5 rounded-full bg-cocoa px-7 py-3.5 text-base font-bold text-gold whitespace-nowrap shrink-0 transition-all duration-200 hover:bg-chocolate hover:-translate-y-0.5 active:translate-y-0"
              >
                <MessageCircle className="h-5 w-5 shrink-0" aria-hidden="true" />
                <span>Conversar no WhatsApp</span>
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7"
          >
            <div className="rounded-[2rem] border border-border-warm bg-honey-elevated p-6 sm:p-10">
              <h3 className="font-display text-2xl font-semibold text-ink-dark">
                Envie seu pedido personalizado
              </h3>
              <p className="mt-1.5 text-sm text-ink-muted">
                Preencha os campos para iniciar sua conversa no WhatsApp com o Chef Ivan e Amanda.
              </p>

              <form onSubmit={handleSubmit} noValidate className="mt-8 space-y-6">
                <div>
                  <label
                    htmlFor="contact-name"
                    className="block text-sm font-bold text-ink-dark"
                  >
                    Seu nome
                  </label>
                  <input
                    id="contact-name"
                    type="text"
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value);
                      if (errors.name) setErrors((prev) => ({ ...prev, name: undefined }));
                    }}
                    placeholder="Ex.: Mariana Silva"
                    aria-invalid={Boolean(errors.name)}
                    aria-describedby={errors.name ? 'error-name' : undefined}
                    className="mt-2 min-h-[48px] w-full rounded-xl border border-border-warm bg-honey px-4 py-3 text-base text-ink-dark placeholder:text-ink-muted/70 transition-colors focus:border-cocoa"
                  />
                  {errors.name && (
                    <p
                      id="error-name"
                      role="alert"
                      className="mt-2 flex items-center gap-1.5 text-sm font-bold text-chocolate"
                    >
                      <AlertCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
                      <span>{errors.name}</span>
                    </p>
                  )}
                </div>

                <div>
                  <label
                    htmlFor="contact-interest"
                    className="block text-sm font-bold text-ink-dark"
                  >
                    Qual linha você deseja?
                  </label>
                  <select
                    id="contact-interest"
                    value={interest}
                    onChange={(e) => setInterest(e.target.value)}
                    className="mt-2 min-h-[48px] w-full rounded-xl border border-border-warm bg-honey px-4 py-3 text-base text-ink-dark transition-colors focus:border-cocoa"
                  >
                    {INTEREST_OPTIONS.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="contact-message"
                    className="block text-sm font-bold text-ink-dark"
                  >
                    Sabores e quantidades
                  </label>
                  <textarea
                    id="contact-message"
                    rows={3}
                    value={message}
                    onChange={(e) => {
                      setMessage(e.target.value);
                      if (errors.message) {
                        setErrors((prev) => ({ ...prev, message: undefined }));
                      }
                    }}
                    placeholder="Ex.: Quero 1 Pudim de Doce de Leite, 1 Brownie de Chocolate e 1 Bombom de Palha Italiana Cremosa."
                    aria-invalid={Boolean(errors.message)}
                    aria-describedby={errors.message ? 'error-message' : undefined}
                    className="mt-2 w-full rounded-xl border border-border-warm bg-honey px-4 py-3 text-base text-ink-dark placeholder:text-ink-muted/70 transition-colors focus:border-cocoa"
                  />
                  {errors.message && (
                    <p
                      id="error-message"
                      role="alert"
                      className="mt-2 flex items-center gap-1.5 text-sm font-bold text-chocolate"
                    >
                      <AlertCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
                      <span>{errors.message}</span>
                    </p>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-4 pt-1">
                  <button
                    type="submit"
                    className="inline-flex min-h-[48px] items-center justify-center gap-2.5 rounded-full bg-cocoa px-7 py-3.5 text-base font-bold text-gold whitespace-nowrap shrink-0 transition-all duration-200 hover:bg-chocolate hover:-translate-y-0.5 active:translate-y-0"
                  >
                    <MessageCircle className="h-5 w-5 shrink-0" aria-hidden="true" />
                    <span>Conversar no WhatsApp</span>
                  </button>
                </div>

                <a
                  ref={hiddenLinkRef}
                  href={submittedUrl || directWhatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="sr-only"
                  tabIndex={-1}
                  aria-hidden="true"
                >
                  Abrir WhatsApp
                </a>

                {submittedUrl && (
                  <div
                    role="status"
                    className="rounded-2xl border border-cocoa/30 bg-gold-soft/65 p-4"
                  >
                    <div className="flex items-start gap-2.5">
                      <CheckCircle2
                        className="mt-0.5 h-5 w-5 shrink-0 text-chocolate"
                        aria-hidden="true"
                      />
                      <div className="text-sm text-ink-dark">
                        <p className="font-bold">Pedido pronto para enviar no WhatsApp.</p>
                        <p className="mt-1 text-ink-muted">
                          Se a janela não abriu automaticamente, toque abaixo para continuar:
                        </p>
                        <a
                          href={submittedUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="mt-2 inline-flex items-center gap-1.5 font-bold text-chocolate underline underline-offset-4 hover:text-ink-dark"
                        >
                          <span>Abrir conversa no WhatsApp</span>
                        </a>
                      </div>
                    </div>
                  </div>
                )}
              </form>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
