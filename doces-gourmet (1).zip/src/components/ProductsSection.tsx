import { useMemo, useState } from 'react';
import { MessageCircle, Minus, Plus, ShoppingBag, Trash2 } from 'lucide-react';
import { motion } from 'motion/react';
import {
  CategoryId,
  PRODUCT_CATEGORIES,
  buildWhatsAppUrl,
  formatBRL,
} from '../data/catalog';
import { MediaFrame } from './MediaFrame';

type FilterValue = 'todos' | CategoryId;

const FILTER_OPTIONS: { value: FilterValue; label: string }[] = [
  { value: 'todos', label: 'Todos' },
  { value: 'sobremesas', label: 'Sobremesas' },
  { value: 'brigadeiros', label: 'Brigadeiros' },
  { value: 'bombons', label: 'Bombons' },
  { value: 'garrafinhas', label: 'Garrafinhas' },
];

export function ProductsSection() {
  const [activeFilter, setActiveFilter] = useState<FilterValue>('todos');
  const [selectedQuantities, setSelectedQuantities] = useState<Record<string, number>>({});

  const visibleCategories =
    activeFilter === 'todos'
      ? PRODUCT_CATEGORIES
      : PRODUCT_CATEGORIES.filter((cat) => cat.id === activeFilter);

  const selectedItems = useMemo(() => {
    const items: { id: string; name: string; price: number; qty: number }[] = [];
    for (const category of PRODUCT_CATEGORIES) {
      for (const item of category.items) {
        const qty = selectedQuantities[item.id] || 0;
        if (qty > 0) {
          items.push({ id: item.id, name: item.name, price: item.price, qty });
        }
      }
    }
    return items;
  }, [selectedQuantities]);

  const totalCount = useMemo(
    () => selectedItems.reduce((sum, item) => sum + item.qty, 0),
    [selectedItems]
  );

  const totalAmount = useMemo(
    () => selectedItems.reduce((sum, item) => sum + item.price * item.qty, 0),
    [selectedItems]
  );

  function updateQuantity(itemId: string, delta: number) {
    setSelectedQuantities((prev) => {
      const next = Math.max(0, (prev[itemId] || 0) + delta);
      if (next === 0) {
        const copy = { ...prev };
        delete copy[itemId];
        return copy;
      }
      return { ...prev, [itemId]: next };
    });
  }

  const orderWhatsappUrl = useMemo(() => {
    if (selectedItems.length === 0) {
      return buildWhatsAppUrl('Olá! Gostaria de fazer um pedido na Doces Gourmet.');
    }
    const lines = selectedItems.map(
      (item) => `• ${item.qty}x ${item.name} (${formatBRL(item.price * item.qty)})`
    );
    return buildWhatsAppUrl(
      `Olá! Gostaria de fazer o seguinte pedido na Doces Gourmet:\n${lines.join('\n')}\nTotal: ${formatBRL(totalAmount)}`
    );
  }, [selectedItems, totalAmount]);

  return (
    <section
      id="produtos"
      className="border-t-2 border-gold/40 bg-honey py-20 text-ink-dark sm:py-28 lg:py-32"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <div className="max-w-xl">
            <p className="text-sm font-bold tracking-wide text-chocolate">
              Cardápio e valores
            </p>
            <h2 className="mt-2 font-display text-[clamp(2rem,3.6vw,3.1rem)] font-semibold leading-[1.08] tracking-tight text-ink-dark">
              Nossas linhas artesanais.
            </h2>
          </div>

          <div
            role="tablist"
            aria-label="Filtrar cardápio por linha"
            className="inline-flex flex-wrap items-center gap-1.5 rounded-2xl border border-border-warm bg-honey-elevated p-1.5 self-start md:self-auto"
          >
            {FILTER_OPTIONS.map((option) => {
              const isSelected = activeFilter === option.value;
              return (
                <button
                  key={option.value}
                  type="button"
                  role="tab"
                  aria-selected={isSelected}
                  onClick={() => setActiveFilter(option.value)}
                  className={`min-h-[40px] rounded-xl px-4 py-2 text-sm font-bold whitespace-nowrap shrink-0 transition-all duration-200 ${
                    isSelected
                      ? 'bg-cocoa text-gold'
                      : 'text-ink-dark hover:bg-gold-soft/50'
                  }`}
                >
                  {option.label}
                </button>
              );
            })}
          </div>
        </div>

        <div className="mt-16 space-y-20 sm:mt-20 sm:space-y-24">
          {visibleCategories.map((category, idx) => (
            <motion.div
              key={category.id}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.1 }}
              transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
            >
              <div className="flex flex-col gap-2 border-b border-border-warm pb-6 sm:flex-row sm:items-end sm:justify-between">
                <div>
                  <p className="text-xs font-bold tracking-wider uppercase text-chocolate">
                    0{idx + 1} · {category.label}
                  </p>
                  <h3 className="mt-1.5 font-display text-[clamp(1.65rem,2.6vw,2.2rem)] font-semibold leading-tight text-ink-dark">
                    {category.title}
                  </h3>
                </div>
                <p className="max-w-md text-sm font-medium leading-relaxed text-ink-muted sm:text-right">
                  {category.subtitle}
                </p>
              </div>

              <div
                className={`mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:gap-7 ${
                  category.items.length === 4 ? 'lg:grid-cols-4' : 'lg:grid-cols-3'
                }`}
              >
                {category.items.map((item) => {
                  const qty = selectedQuantities[item.id] || 0;
                  const directItemUrl = buildWhatsAppUrl(
                    `Olá! Gostaria de pedir "${item.name}" (${formatBRL(item.price)}) na Doces Gourmet.`
                  );

                  return (
                    <article
                      key={item.id}
                      className="group flex flex-col justify-between overflow-hidden rounded-[1.5rem] border border-border-warm bg-honey-elevated transition-all duration-200 hover:-translate-y-0.5 hover:border-cocoa"
                    >
                      <div>
                        <MediaFrame
                          src={item.image}
                          alt={item.imageAlt}
                          label={item.name}
                          className="aspect-[4/3] w-full border-b border-border-warm"
                          imgClassName="transition-transform duration-500 ease-out group-hover:scale-[1.03]"
                        />
                        <div className="p-5">
                          <h4 className="font-display text-lg font-semibold leading-snug text-ink-dark">
                            {item.name}
                          </h4>
                          <p className="mt-1.5 text-sm leading-relaxed text-ink-muted">
                            {item.description}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between gap-3 border-t border-border-warm/60 bg-gold-soft/35 px-5 py-4">
                        <a
                          href={directItemUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="font-display text-lg font-bold text-ink-dark tabular-nums transition-colors hover:text-chocolate"
                          title={`Pedir ${item.name} no WhatsApp`}
                        >
                          {formatBRL(item.price)}
                        </a>

                        {qty === 0 ? (
                          <button
                            type="button"
                            onClick={() => updateQuantity(item.id, 1)}
                            aria-label={`Adicionar ${item.name} ao pedido`}
                            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-full bg-cocoa px-4 py-2 text-sm font-bold text-gold whitespace-nowrap shrink-0 transition-colors duration-200 hover:bg-chocolate"
                          >
                            <Plus className="h-4 w-4 shrink-0" aria-hidden="true" />
                            <span>Adicionar</span>
                          </button>
                        ) : (
                          <div className="inline-flex min-h-[40px] items-center rounded-full border border-cocoa bg-gold px-1 py-1">
                            <button
                              type="button"
                              onClick={() => updateQuantity(item.id, -1)}
                              aria-label={`Remover uma unidade de ${item.name}`}
                              className="flex h-8 w-8 items-center justify-center rounded-full text-ink-dark transition-colors hover:bg-honey-elevated"
                            >
                              <Minus className="h-4 w-4" aria-hidden="true" />
                            </button>
                            <span
                              aria-label={`Quantidade de ${item.name}: ${qty}`}
                              className="min-w-[1.75rem] text-center text-sm font-bold text-ink-dark tabular-nums"
                            >
                              {qty}
                            </span>
                            <button
                              type="button"
                              onClick={() => updateQuantity(item.id, 1)}
                              aria-label={`Adicionar mais uma unidade de ${item.name}`}
                              className="flex h-8 w-8 items-center justify-center rounded-full text-ink-dark transition-colors hover:bg-honey-elevated"
                            >
                              <Plus className="h-4 w-4" aria-hidden="true" />
                            </button>
                          </div>
                        )}
                      </div>
                    </article>
                  );
                })}
              </div>
            </motion.div>
          ))}
        </div>

        {totalCount > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className="mt-16 rounded-[2rem] border-2 border-gold bg-cocoa p-6 text-cream sm:p-8"
          >
            <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
              <div className="flex items-start gap-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gold text-ink-dark">
                  <ShoppingBag className="h-5 w-5" aria-hidden="true" />
                </div>
                <div>
                  <p className="font-display text-xl font-semibold text-cream tabular-nums">
                    Seu pedido ({totalCount} {totalCount === 1 ? 'item' : 'itens'}) ·{' '}
                    <span className="text-gold">{formatBRL(totalAmount)}</span>
                  </p>
                  <p className="mt-1 text-sm leading-relaxed text-cream-muted">
                    {selectedItems
                      .map((item) => `${item.qty}x ${item.name} (${formatBRL(item.price * item.qty)})`)
                      .join(' · ')}
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3 shrink-0">
                <button
                  type="button"
                  onClick={() => setSelectedQuantities({})}
                  className="inline-flex min-h-[44px] items-center gap-1.5 rounded-full border border-border-dark bg-chocolate px-4 py-2.5 text-sm font-semibold text-cream whitespace-nowrap shrink-0 transition-colors hover:border-gold hover:text-gold"
                >
                  <Trash2 className="h-4 w-4 shrink-0" aria-hidden="true" />
                  <span>Limpar</span>
                </button>

                <a
                  href={orderWhatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-full bg-gold px-6 py-3 text-sm font-bold text-ink-dark whitespace-nowrap shrink-0 transition-all duration-200 hover:bg-gold-hover"
                >
                  <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
                  <span>Enviar pedido pelo WhatsApp</span>
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </section>
  );
}
