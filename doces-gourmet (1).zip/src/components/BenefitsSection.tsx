import { MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { DOCERIA_VALUES, buildWhatsAppUrl } from '../data/catalog';

export function BenefitsSection() {
  const whatsappHref = buildWhatsAppUrl(
    'Olá! Quero saber mais sobre os doces e encomendas da Doces Gourmet.'
  );

  return (
    <section className="bg-gold py-20 text-ink-dark sm:py-28 lg:py-32">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="mx-auto max-w-2xl text-center"
        >
          <p className="text-sm font-bold tracking-wide text-chocolate">
            Doce é sempre uma boa ideia
          </p>
          <h2 className="mt-3 font-display text-[clamp(2rem,4vw,3.35rem)] font-semibold leading-[1.08] tracking-tight text-ink-dark">
            Uma experiência de sabor em cada detalhe.
          </h2>
        </motion.div>

        <div className="mt-14 divide-y divide-ink-dark/20 border-y border-ink-dark/20 sm:mt-16">
          {DOCERIA_VALUES.map((item, idx) => (
            <motion.div
              key={item.index}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.55, delay: idx * 0.06, ease: [0.16, 1, 0.3, 1] }}
              className="grid grid-cols-1 items-baseline gap-4 py-8 sm:grid-cols-12 sm:gap-8 sm:py-10"
            >
              <span className="font-display text-2xl font-semibold text-chocolate tabular-nums sm:col-span-2 sm:text-3xl">
                {item.index}
              </span>
              <h3 className="font-display text-2xl font-semibold leading-snug text-ink-dark sm:col-span-4">
                {item.title}
              </h3>
              <p className="text-base font-medium leading-relaxed text-ink-dark/85 sm:col-span-6 sm:text-lg">
                {item.description}
              </p>
            </motion.div>
          ))}
        </div>

        <div className="mt-12 flex justify-center">
          <a
            href={whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex min-h-[48px] items-center justify-center gap-2.5 rounded-full bg-cocoa px-7 py-3.5 text-base font-bold text-gold whitespace-nowrap shrink-0 transition-transform duration-200 hover:bg-chocolate hover:-translate-y-0.5 active:translate-y-0"
          >
            <MessageCircle className="h-5 w-5 shrink-0" aria-hidden="true" />
            <span>Conversar no WhatsApp</span>
          </a>
        </div>
      </div>
    </section>
  );
}
